rm(list=ls())
ls()
a <- 10
b = 20
hap <- a + b
cat(a,'+', b, '=', hap, "\n")
ls()
rm(hap)
ls()
a_list = 10
a.so = 20
#1abc = 30